#include <iostream>

using namespace std ;
int main()
{
       int m , n , x ;
       cout << "Enter A Number : " ;
       cin >> x ;
       for(m = 1 ; m <= x ; m++)
	   {
      	 for(n = 1 ; n <= x ; n++)
	          cout << m * n << "\t" ;
	       cout << endl ;
       }
       return 0;
}
