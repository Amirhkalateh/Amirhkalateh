#include <iostream>
#include <conio.h>

using namespace std ;

int main()
{
  int wordCount = 1;
  char ch;
  cout << "\nEnter a statement(and press ENTER):";
  while((ch = getche()) != '\r')
  {
    if(ch == ' ')
	wordCount ++;
  }
  cout <<"\n Word count=" << wordCount ;
  return 0;
}
